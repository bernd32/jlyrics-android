package com.bernd32.jlyrics.utils;

import org.junit.Test;

import static org.junit.Assert.*;

public class KanaToRomajiTest {

    @Test
    public void convert() {
    }
}