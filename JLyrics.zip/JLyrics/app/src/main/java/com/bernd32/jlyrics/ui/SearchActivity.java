package com.bernd32.jlyrics.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bernd32.jlyrics.PaginationListener;
import com.bernd32.jlyrics.PostItem;
import com.bernd32.jlyrics.R;
import com.bernd32.jlyrics.adapters.PostRecyclerAdapter;
import com.bernd32.jlyrics.async.AsyncTaskListener;
import com.bernd32.jlyrics.async.GetDataAsyncTask;
import com.bernd32.jlyrics.utils.PreferencesManager;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.Locale;

import static com.bernd32.jlyrics.PaginationListener.PAGE_START;

public class SearchActivity extends AppCompatActivity {


    private static final String TAG = "SearchActivity";
    public static final String NO_IMG = "no_img";
    @SuppressWarnings("WeakerAccess")
    public RecyclerView mRecyclerView; // must not be private or static
    private ProgressBar progressBar;
    private PostRecyclerAdapter adapter;
    private int currentPage = PAGE_START;
    private boolean isLastPage = false;
    private boolean isLoading = false;
    private String searchInput;
    private int spinnerPos;
    private String artistText;
    private String songText;
    private String lyricsText;
    private int artistSpinnerPos;
    private int songSpinnerPos;
    private int lyricsSpinnerPos;
    private boolean ignoreMainSearch;
    private FloatingActionButton floatingActionButton;
    private ExtendedFloatingActionButton cancelFAB;
    private GetDataAsyncTask task;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: has been called");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            intentLoader();
        }
        progressBar = findViewById(R.id.progress_bar);
        mRecyclerView = findViewById(R.id.recyclerv_view);
        floatingActionButton = findViewById(R.id.floating_action_button);
        cancelFAB = findViewById(R.id.load_cancel);
        // Find the toolbar view inside the activity layout
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        adapter = new PostRecyclerAdapter(this, new ArrayList<>());
        mRecyclerView.setAdapter(adapter);
        // initial load
        String url = ignoreMainSearch ?
                urlBuilder(PAGE_START, artistText, artistSpinnerPos, songText,
                        songSpinnerPos, lyricsText, lyricsSpinnerPos) :
                urlBuilder(PAGE_START, spinnerPos, searchInput);
        startAsyncTask(url);
        /*
         * add scroll listener while user reach in bottom load more will call
         */
        mRecyclerView.addOnScrollListener(new PaginationListener(layoutManager) {
            @Override
            protected void loadMoreItems() {
                isLoading = true;
                currentPage++;
                String url = ignoreMainSearch ?
                        urlBuilder(currentPage, artistText, artistSpinnerPos, songText,
                                songSpinnerPos, lyricsText, lyricsSpinnerPos) :
                        urlBuilder(currentPage, spinnerPos, searchInput);
                floatingActionButton.setVisibility(View.VISIBLE);
                startAsyncTask(url);
            }

            @Override
            public boolean isLastPage() {
                return isLastPage;
            }

            @Override
            public boolean isLoading() {
                return isLoading;
            }

            @Override
            protected void showFAB() {
                if(floatingActionButton.getVisibility() != View.VISIBLE) {
                    floatingActionButton.show();
                }
            }

            @Override
            protected void hideFAB() {
                if(floatingActionButton.getVisibility() == View.VISIBLE) {
                    floatingActionButton.hide();
                }
            }
        });
        floatingActionButton.setOnClickListener(view -> {
            mRecyclerView.smoothScrollToPosition(0);
        });
    }

    public void onLoadCancel(View view) {
        if (task != null)
            task.cancel(true);
        finish();
    }

    private void intentLoader() {
        Intent intent = getIntent();
        searchInput = intent.getStringExtra(MainActivity.SEARCH_QUERY_SONG);
        spinnerPos = intent.getIntExtra(MainActivity.SPINNER_LIST, 0);
        artistText = intent.getStringExtra(MainActivity.ARTIST_INPUT);
        songText = intent.getStringExtra(MainActivity.SONG_INPUT);
        lyricsText = intent.getStringExtra(MainActivity.LYRICS_INPUT);
        artistSpinnerPos = intent.getIntExtra(MainActivity.ARTIST_SPINNER, 0);
        songSpinnerPos = intent.getIntExtra(MainActivity.SONG_SPINNER, 0);
        lyricsSpinnerPos = intent.getIntExtra(MainActivity.LYRICS_SPINNER, 0);
        ignoreMainSearch = intent.getBooleanExtra(MainActivity.IGNORE_MAIN_SEARCH_INPUT, false);
    }


    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart: activated");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: activated");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: activated");
        adapter.clear();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        // Get saved data and set value to the checkable menu item
        MenuItem darkThemeItem = menu.findItem(R.id.dark_theme);
        PreferencesManager.initializeInstance(this);
        PreferencesManager pm = PreferencesManager.getInstance();
        darkThemeItem.setChecked(pm.getDarkThemeSelected());
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.toolbar_show_favs:
                Intent intent = new Intent(this, FavoritesActivity.class);
                startActivity(intent);
                return true;
            case R.id.quit:
                this.finishAffinity();
                return true;
            case R.id.dark_theme:
                item.setChecked(!item.isChecked());
                // Save to value
                PreferencesManager.initializeInstance(this);
                PreferencesManager pm = PreferencesManager.getInstance();
                pm.setDarkThemeSelected(item.isChecked());
                if (item.isChecked()) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void startAsyncTask(String url) {
        Log.d(TAG, "startAsyncTask: " + url);
         task = new GetDataAsyncTask(new AsyncTaskListener<Document>() {
            @Override
            public void onPreTask() {
                Log.d(TAG, "onPreTask: started");
                // show progressbar only in initial loading
                if(currentPage == 1) {
                    progressBar.setVisibility(View.VISIBLE);
                    mRecyclerView.setVisibility(View.GONE);
                    cancelFAB.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPostTask(Document doc) {
                Log.d(TAG, "onPostTask: started");
                if (currentPage == 1) {
                    progressBar.setVisibility(View.GONE);
                    mRecyclerView.setVisibility(View.VISIBLE);
                    cancelFAB.setVisibility(View.GONE);
                }
                documentHandler(doc);
            }

            @Override
            public void onFailure(Exception e, int statusCode) {
                Toast.makeText(SearchActivity.this,
                        getString(R.string.connection_failed),
                        Toast.LENGTH_LONG).show();
                finish();
                // TODO: 24.11.2019 log Exception e and int statusCode
                Log.d(TAG, "onFailure: " + e.toString());
            }
        });
        task.execute(url);
    }

    private String urlBuilder(int page, int spinnerPos, String searchInput) {
        // Used for simple search
        Log.d(TAG, "urlBuilder for simple search");
        StringBuilder url = new StringBuilder("http://search.j-lyric.net/index.php?&ct=2&ca=2&cl=2&p=");
        final int SONG_NAME_SELECTED = 0;
        final int ARTIST_SELECTED = 1;
        final int LYRICS_SELECTED = 2;
        switch (spinnerPos) {
            case SONG_NAME_SELECTED:
                url.append(page).append("&kt=").append(searchInput);
                break;
            case ARTIST_SELECTED:
                url.append(page).append("&ka=").append(searchInput);
                break;
            case LYRICS_SELECTED:
                url.append(page).append("&kl=").append(searchInput);
                break;
        }
        Log.d(TAG, "urlBuilder: " + url.toString());
        return url.toString();
    }

    private String urlBuilder(int page, String artistText, int artistSpinnerPos, String songText,
                              int songSpinnerPos, String lyricsText, int lyricsSpinnerPos) {
        // Used for detailed search
        Log.d(TAG, "urlBuilder for detailed search");
        if (lyricsSpinnerPos > 0) lyricsSpinnerPos += 1;
        String url = String.format(Locale.getDefault(), 
                "http://search.j-lyric.net/index.php?p=%d&kt=%s&ct=%d&ka=%s&ca=%d&kl=%s&cl=%d",
                page, songText, songSpinnerPos, artistText, artistSpinnerPos, lyricsText, lyricsSpinnerPos);
        Log.d(TAG, "urlBuilder: " + url);
        return url;
    }

    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(SearchActivity.this);
        builder.setTitle(getString(R.string.not_found_title));
        builder.setMessage(getString(R.string.not_found_message));
        builder.setPositiveButton(R.string.ok, (dialog, id) -> {
            dialog.dismiss();
            finish();
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void documentHandler(Document doc) {
        // Extract elements from a search page result and set them to recyсle adapter
        Log.d(TAG, "documentHandler: activated");
        String description = doc.select("meta[name=description]").first().attr("content");
        Elements lyricsNumber = doc.select("#mnb > div > p.sml:contains(収録数：)");
        int pageType = getPageType(description, lyricsNumber);
        final ArrayList<PostItem> items = new ArrayList<>();
        int maxPage = 1;
        if (pageType == PostRecyclerAdapter.SONG_PAGE) {
            Elements imgElements = doc.select("#mnb > div.bdy");
            Elements urls = doc.select("#mnb > div > p.mid > a");
            Elements songNames = doc.select("#mnb > div.bdy > p.mid");
            Elements artists = doc.select("#mnb > div.bdy > p.sml:contains(歌：)");
            Element pageUrlElement = doc.select("#pager > a").first();
            // Show alert dialog if nothing found
            if (artists.size() == 0) {
                showAlertDialog();
            } else {
                for (int i = 0; i < artists.size(); i++) {
                    PostItem postItem = new PostItem();
                    String imgSrc = imgElements.get(i).select("a > img").attr("src");
                    if (!imgSrc.isEmpty()) {
                        postItem.setImgUrl(imgSrc);
                    } else {
                        postItem.setImgUrl(NO_IMG);
                    }
                    String url = urls.get(i).attr("href");
                    postItem.setSongUrl(url);
                    postItem.setCardTitle(songNames.get(i).text());
                    postItem.setCardDescription(artists.get(i).text().replace("歌：", ""));
                    items.add(postItem);
                    maxPage = numberOfPages(getNumberOfSongsFound(pageUrlElement));
                }
                SearchActivity.this.setTitle(getString(R.string.title_found) +
                        " " + getNumberOfSongsFound(pageUrlElement));
            }
        }
        if (pageType == PostRecyclerAdapter.ARTISTS_PAGE) {
            // Handles artist search result
            Elements imgElements = doc.select("#mnb > div.bdy");
            Elements artists = doc.select("#mnb > div > p.mid > a");
            Elements urls = doc.select("#mnb > div > p.mid > a");
            // Show alert dialog if nothing found
            if (artists.size() == 0) {
                showAlertDialog();
            } else {
                for (int i = 0; i < artists.size(); i++) {
                    PostItem postItem = new PostItem();
                    String getArtist = artists.get(i).text();
                    String getNumberOfSongs = lyricsNumber.get(i).text()
                            .replace("収録数：", "Lyrics: ")
                            .replace("曲", "");
                    String imgSrc = imgElements.get(i).select("a > img").attr("src");
                    if (!imgSrc.isEmpty()) {
                        postItem.setImgUrl(imgSrc);
                    } else {
                        postItem.setImgUrl(NO_IMG);
                    }
                    String artistUrl = urls.get(i).attr("href");
                    postItem.setCardTitle(getArtist);
                    postItem.setCardDescription(getNumberOfSongs);
                    postItem.setArtistUrl(artistUrl);
                    items.add(postItem);
                    maxPage = 1;
                }
                SearchActivity.this.setTitle(getString(R.string.title_found) +
                        " " + artists.size());
            }
        }
        newPageLoader(maxPage, items);
    }

    private void newPageLoader(int maxPage, ArrayList<PostItem> items) {
        if (currentPage != PAGE_START)  {
            adapter.removeLoading();
        }
        adapter.addItems(items);
        // check whether is last page or not
        if (currentPage < maxPage) {
            adapter.addLoading();
        } else {
            isLastPage = true;
        }
        isLoading = false;
        Log.d(TAG, String.format("Loaded page: %d/%d", currentPage, maxPage));
    }

    private int getPageType(String description, Elements lyricsNumber) {
        int pageType;
        // keywords for detecting a page type
        final String search_result_keyword = "検索結果ページ";
        final String lyrics_page_keyword = "歌詞ページ";
        final String artist_list_keyword = "歌詞一覧ページ";
        final String artist_search_result_keyword = "歌手名に";
        if (description.contains(search_result_keyword) && lyricsNumber.isEmpty()) {
            // Song search result (has pages)
            Log.d(TAG, "getPageType: Search result page detected");
            pageType = PostRecyclerAdapter.SONG_PAGE;
            adapter.setPageType(pageType);
            return pageType;

        } else if (description.contains(lyrics_page_keyword)) {
            Log.d(TAG, "getPageType: Lyrics page detected");
            pageType = PostRecyclerAdapter.LYRICS_PAGE;
            adapter.setPageType(pageType);
            return pageType;
        } else if (description.contains(artist_list_keyword)) {
            Log.d(TAG, "getPageType: Artist list page detected");
            pageType = PostRecyclerAdapter.ARTIST_LYRICS_PAGE;
            adapter.setPageType(pageType);
            return pageType;
        } else if(description.contains(artist_search_result_keyword) && !lyricsNumber.isEmpty()) {
            Log.d(TAG, "getPageType: Artist search result page detected");
            pageType = PostRecyclerAdapter.ARTISTS_PAGE;
            adapter.setPageType(pageType);
            return pageType;
        } else {
            Log.d(TAG, "getPageType: cannot detect page type");
            return PostRecyclerAdapter.SONG_PAGE;
        }
    }

    private int numberOfPages(int songs) {
        double p = Math.ceil((double) songs/20);
        return (int) p;
    }

    private int getNumberOfSongsFound(Element pageUrlElement) {
        String url = pageUrlElement.attr("href");
        Uri uri = Uri.parse(url);
        String c = uri.getQueryParameter("c");
        assert c != null;
        return Integer.valueOf(c);
    }
}
