package com.bernd32.jlyrics.async;


import android.os.AsyncTask;

import com.bernd32.jlyrics.romanizer.RomajiHenkan;

public class RomanizeAsyncTask extends AsyncTask<String, Void, String> {

    private AsyncTaskListener<String> listener;

    public RomanizeAsyncTask(AsyncTaskListener<String> listener) {
        this.listener = listener;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        listener.onPreTask();
    }

    @Override
    protected void onPostExecute(String string) {
        if (listener != null) {
            listener.onPostTask(string);
        }
        super.onPostExecute(string);
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override
    protected String doInBackground(String... strings) {
        RomajiHenkan henkan = new RomajiHenkan();
        return henkan.convert(strings[0]);
    }
}
