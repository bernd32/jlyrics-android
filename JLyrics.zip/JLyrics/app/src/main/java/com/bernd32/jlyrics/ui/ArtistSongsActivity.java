package com.bernd32.jlyrics.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bernd32.jlyrics.PaginationListener;
import com.bernd32.jlyrics.PostItem;
import com.bernd32.jlyrics.R;
import com.bernd32.jlyrics.adapters.PostRecyclerAdapter;
import com.bernd32.jlyrics.async.AsyncTaskListener;
import com.bernd32.jlyrics.async.GetDataAsyncTask;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.ArrayList;

public class ArtistSongsActivity extends AppCompatActivity {

    private static final String TAG = "SearchActivity";
    private static final String NO_IMG = "no_img";
    @SuppressWarnings("WeakerAccess")
    public RecyclerView mRecyclerView;
    private ProgressBar progressBar;
    private PostRecyclerAdapter adapter;
    private String url;
    private FloatingActionButton floatingActionButton;
    private ExtendedFloatingActionButton cancelFAB;
    private GetDataAsyncTask task;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: started");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        cancelFAB = findViewById(R.id.load_cancel);
        progressBar = findViewById(R.id.progress_bar);
        mRecyclerView = findViewById(R.id.recyclerv_view);
        floatingActionButton = findViewById(R.id.floating_action_button);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            loadIntents();
        }
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        adapter = new PostRecyclerAdapter(this, new ArrayList<>());
        mRecyclerView.setAdapter(adapter);
        startAsyncTask(url);
        floatingActionButton.setOnClickListener(view -> mRecyclerView.smoothScrollToPosition(0));
        mRecyclerView.addOnScrollListener(new PaginationListener(layoutManager) {
            @Override
            protected void loadMoreItems() {
                floatingActionButton.setVisibility(View.VISIBLE);
            }

            @Override
            public boolean isLastPage() {
                return true;
            }

            @Override
            public boolean isLoading() {
                return false;
            }

            @Override
            protected void showFAB() {
                if(floatingActionButton.getVisibility() != View.VISIBLE) {
                    floatingActionButton.show();
                }
            }

            @Override
            protected void hideFAB() {
                if(floatingActionButton.getVisibility() == View.VISIBLE) {
                    floatingActionButton.hide();
                }
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    public void onLoadCancel(View view) {
        if (task != null)
            task.cancel(true);
        finish();
    }

    private void loadIntents() {
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        String description = intent.getStringExtra("description");
        url = intent.getStringExtra("url");
        String imgUrl = intent.getStringExtra("img_url");
    }

    private void startAsyncTask(String url) {
        Log.d(TAG, "startAsyncTask: " + url);
        task = new GetDataAsyncTask(new AsyncTaskListener<Document>() {
            @Override
            public void onPreTask() {
                Log.d(TAG, "onPreTask: started");
                // show progressbar only in initial loading
                progressBar.setVisibility(View.VISIBLE);
                cancelFAB.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPostTask(Document doc) {
                Log.d(TAG, "onPostTask: started");
                progressBar.setVisibility(View.GONE);
                cancelFAB.setVisibility(View.GONE);
                documentHandler(doc);
            }

            @Override
            public void onFailure(Exception e, int statusCode) {
                Toast.makeText(ArtistSongsActivity.this,
                        getString(R.string.connection_failed),
                        Toast.LENGTH_LONG).show();
                finish();
                Log.d(TAG, "onFailure: " + e.toString());
            }
        });
        task.execute(url);
    }

    private void documentHandler(Document doc) {
        // Handles artist's list of lyrics
        final ArrayList<PostItem> items = new ArrayList<>();
        adapter.setPageType(PostRecyclerAdapter.ARTIST_LYRICS_PAGE);
        adapter.clear();

        Elements imgElements = doc.select("#mnb > div.cnt > div[id^=ly]");
        Elements titles = doc.select("#mnb > div.cnt > div[id^=ly] > p.ttl > a");
        String description = doc.selectFirst("#mnb > div.cnt > div.cap > h2").text();
        for (int i = 0; i < titles.size(); i++) {
            PostItem postItem = new PostItem();
            String imgSrc = imgElements.get(i).select("a > img.i5r").attr("src");
            if (!imgSrc.isEmpty()) {
                Log.d(TAG, i + " = " + imgSrc);
                postItem.setImgUrl(imgSrc);
            } else {
                Log.d(TAG, "artistDocumentHandle: no image found");
                postItem.setImgUrl(NO_IMG);
            }
            String title = titles.get(i).text();
            String url = titles.get(i).attr("href");
            postItem.setCardTitle(title);
            postItem.setCardDescription(description.replace("の歌詞リスト",  "")); // leave blank for now
            postItem.setSongUrl("http://j-lyric.net" + url);
            Log.d(TAG, "documentHandler: url = http://j-lyric.net" + url);
            items.add(postItem);
        }
        ArtistSongsActivity.this.setTitle(getString(R.string.title_found) +
                " " + titles.size());
        adapter.addItems(items);

    }
}
