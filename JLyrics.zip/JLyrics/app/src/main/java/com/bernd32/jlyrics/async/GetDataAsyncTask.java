package com.bernd32.jlyrics.async;

import android.os.AsyncTask;
import android.util.Log;

import com.bernd32.jlyrics.utils.HelperClass;

import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class GetDataAsyncTask extends AsyncTask<String, Void, Document> { // <[Input_Parameter Type], [Progress_Report Type], [Result Type]>
    private static final String TAG = "GetDataAsyncTask";
    private Exception exception;
    private int httpStatusCode;
    private AsyncTaskListener<Document> listener;

    public GetDataAsyncTask(AsyncTaskListener<Document> listener) {
        this.listener = listener;
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        listener.onPreTask();
    }

    @Override
    protected Document doInBackground(String... params) {
        String url = params[0];
        Log.d(TAG, "doInBackground: loading url: " + url);
        Document doc;
        String userAgent = HelperClass.getUserAgent();
        try {
            doc = Jsoup
                    .connect(url)
                    .userAgent(userAgent)
                    .referrer("https://www.google.co.jp/")
                    .get();
        } catch (Exception e) {
            if (e instanceof HttpStatusException) {
                httpStatusCode = ((HttpStatusException) e).getStatusCode();
            }
            exception = e;
            Log.d(TAG, "doInBackground: " + e.getMessage());
            return null;
        }
        return doc.outputSettings(new Document.OutputSettings().prettyPrint(false));
    }

    protected void onPostExecute(Document s) {
        super.onPostExecute(s);
        if (listener != null) {
            if (exception == null) {
                listener.onPostTask(s);
            } else {
                listener.onFailure(exception, httpStatusCode);
            }
        }

    }
}
