package com.bernd32.jlyrics.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesManager {

/*    a thread-safe singleton class to make the global access method
    synchronized, so that only one thread can execute this method at a time */

    private static final String APP_PREFS = "com.bernd32.jlyrics.prefs";
    private static final String FONT_SIZE = "com.example.app.fontsize";
    private static final String DARK_THEME = "com.example.app.darktheme";

    private static PreferencesManager sInstance;
    private final SharedPreferences mPref;

    private PreferencesManager(Context context) {
        mPref = context.getSharedPreferences(APP_PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized void initializeInstance(Context context) {
        if (sInstance == null) {
            sInstance = new PreferencesManager(context);
        }
    }

    public static synchronized PreferencesManager getInstance() {
        if (sInstance == null) {
            throw new IllegalStateException(PreferencesManager.class.getSimpleName() +
                    " is not initialized, call initializeInstance(..) method first.");
        }
        return sInstance;
    }

    public void setFontSize(int value) {
        mPref.edit()
                .putInt(FONT_SIZE, value)
                .apply();
    }

    public int getFontSize() {
        return mPref.getInt(FONT_SIZE, 20);
    }

    public void setDarkThemeSelected(boolean value) {
        mPref.edit()
                .putBoolean(DARK_THEME, value)
                .apply();
    }

    public boolean getDarkThemeSelected() {
        return mPref.getBoolean(DARK_THEME, false);
    }

    public void remove(String key) {
        mPref.edit()
                .remove(key)
                .apply();
    }

    public boolean clear() {
        return mPref.edit()
                .clear()
                .commit();
    }
}
