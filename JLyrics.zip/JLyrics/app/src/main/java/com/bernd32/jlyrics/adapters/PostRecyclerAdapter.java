package com.bernd32.jlyrics.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bernd32.jlyrics.BaseViewHolder;
import com.bernd32.jlyrics.PostItem;
import com.bernd32.jlyrics.R;
import com.bernd32.jlyrics.ui.ArtistSongsActivity;
import com.bernd32.jlyrics.ui.SearchActivity;
import com.bernd32.jlyrics.ui.ShowLyricsActivity;
import com.bumptech.glide.Glide;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class PostRecyclerAdapter extends RecyclerView.Adapter<BaseViewHolder> {
    private static final String TAG = "PostRecyclerAdapter";
    private static final int VIEW_TYPE_LOADING = 0;
    private static final int VIEW_TYPE_NORMAL = 1;
    public static final int SONG_PAGE = 0;
    public static final int ARTIST_LYRICS_PAGE = 1;
    public static final int ARTISTS_PAGE = 2;
    public static final int LYRICS_PAGE = 3;
    private boolean isLoaderVisible = false;
    private List<PostItem> mPostItems;
    private Context mContext;
    private int pageType;

    public PostRecyclerAdapter(Context context, List<PostItem> postItems) {
        Log.d(TAG, "PostRecyclerAdapter: constructor activated");
        this.mPostItems = postItems;
        this.mContext = context;
    }

    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        switch (viewType) {
            case VIEW_TYPE_NORMAL:
                return new ViewHolder(
                        LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_listitem, parent, false));
            case VIEW_TYPE_LOADING:
                return new ProgressHolder(
                        LayoutInflater.from(parent.getContext()).inflate(R.layout.item_loading, parent, false));
            default:
                return null;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder holder, int position) {
        holder.onBind(position);
    }

    @Override
    public int getItemViewType(int position) {
        if (isLoaderVisible) {
            return position == mPostItems.size() - 1 ? VIEW_TYPE_LOADING : VIEW_TYPE_NORMAL;
        } else {
            return VIEW_TYPE_NORMAL;
        }
    }

    @Override
    public int getItemCount() {
        return mPostItems == null ? 0 : mPostItems.size();
    }

    public void addItems(List<PostItem> postItems) {
        mPostItems.addAll(postItems);
        notifyDataSetChanged();
    }

    public void addLoading() {
        isLoaderVisible = true;
        mPostItems.add(new PostItem());
        notifyItemInserted(mPostItems.size() - 1);
    }

    public void removeLoading() {
        isLoaderVisible = false;
        int position = mPostItems.size() - 1;
        PostItem item = getItem(position);
        if (item != null) {
            mPostItems.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void clear() {
        // use it when performing new search
        mPostItems.clear();
        notifyDataSetChanged();
        Glide.get(mContext).clearMemory();
    }

    private PostItem getItem(int position) {
        return mPostItems.get(position);
    }

    public void setPageType(int pageType) {
        this.pageType = pageType;
    }

    public class ViewHolder extends BaseViewHolder {
        TextView cardTitle;
        TextView cardDescription;
        ImageView image;
        MaterialCardView parentLayout;

        ViewHolder(View itemView) {
            super(itemView);
            cardTitle = itemView.findViewById(R.id.card_title);
            cardDescription = itemView.findViewById(R.id.card_description);
            image = itemView.findViewById(R.id.image);
            parentLayout = itemView.findViewById(R.id.parent_layout);
        }

        protected void clear() {

        }

        public void onBind(int position) {
            super.onBind(position);
            PostItem item = mPostItems.get(position);
            cardTitle.setText(item.getCardTitle());
            cardDescription.setText(item.getCardDescription());
            // If no picture found, set default picture
            if (item.getImgUrl().equals(SearchActivity.NO_IMG)) {
                image.setImageResource(R.mipmap.ic_launcher);
            } else {

                Glide.with(mContext)
                        .asBitmap()
                        .load(item.getImgUrl())
                        .into(image);
            }
            // click listener
            parentLayout.setOnClickListener(view -> {
                Log.d(TAG, "onBind: " + pageType);
                if (pageType == SONG_PAGE || pageType == ARTIST_LYRICS_PAGE) {
                    Intent intent = new Intent(mContext, ShowLyricsActivity.class);
                    intent.putExtra("song_url", item.getSongUrl());
                    intent.putExtra("title", item.getCardTitle());
                    intent.putExtra("description", item.getCardDescription());
                    intent.putExtra("img_url", item.getImgUrl());
                    mContext.startActivity(intent);
                } else {
                    Intent intent = new Intent(mContext, ArtistSongsActivity.class);
                    intent.putExtra("url", item.getArtistUrl());
                    intent.putExtra("title", item.getCardTitle());
                    intent.putExtra("description", item.getCardDescription());
                    intent.putExtra("img_url", item.getImgUrl());
                    mContext.startActivity(intent);
                }
            });
        }
    }

    protected class ProgressHolder extends BaseViewHolder {
        ProgressHolder(View itemView) {
            super(itemView);
        }

        @Override
        protected void clear() {
        }
    }
}
