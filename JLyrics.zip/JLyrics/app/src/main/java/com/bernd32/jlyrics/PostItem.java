package com.bernd32.jlyrics;

public class PostItem {

  private String cardTitle;
  private String cardDescription;
  private String imgUrl;
  private String songUrl;
  private String artistUrl;
  private String url;

  public String getArtistUrl() {
    return artistUrl;
  }

  public void setArtistUrl(String artistUrl) {
    this.artistUrl = artistUrl;
  }

  public String getCardTitle() {
    return cardTitle;
  }

  public void setCardTitle(String cardTitle) {
    this.cardTitle = cardTitle;
  }

  public String getCardDescription() {
    return cardDescription;
  }

  public void setCardDescription(String cardDescription) {
    this.cardDescription = cardDescription;
  }

  public String getImgUrl() {
    return imgUrl;
  }

  public void setImgUrl(String imgUrl) {
    this.imgUrl = imgUrl;
  }

  public String getSongUrl() {
    return songUrl;
  }

  public void setSongUrl(String songUrl) {
    this.songUrl = songUrl;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }
}
