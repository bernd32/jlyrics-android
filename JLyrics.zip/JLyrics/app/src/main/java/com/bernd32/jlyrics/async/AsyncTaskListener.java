package com.bernd32.jlyrics.async;


public interface AsyncTaskListener<T> {
    // Used for UI callbacks from AsynkTask class
    void onPreTask();
    void onPostTask(T object);
    void onFailure(Exception e, int statusCode);
}