package com.bernd32.jlyrics.async;

import android.os.AsyncTask;
import android.util.Log;

import com.bernd32.jlyrics.utils.HelperClass;

import org.jsoup.Connection;
import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class PostDataAsyncTask extends AsyncTask<String, Void, Document> { // <[Input_Parameter Type], [Progress_Report Type], [Result Type]>
    private static final String TAG = "PostDataAsyncTask";
    private Exception exception;
    private int httpStatusCode;
    private AsyncTaskListener<String> listener;

    public PostDataAsyncTask(AsyncTaskListener<String> listener) {
        this.listener = listener;
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        listener.onPreTask();
    }

    @Override
    protected Document doInBackground(String... params) {
        // params[0] is a lyric text
        String url;
        url = "https://www.jcinfo.net/ja/tools/kana";
        Log.d(TAG, "doInBackground: params="+params[0]);
        Document doc;
        String userAgent = HelperClass.getUserAgent();
        try {

            Connection.Response response = Jsoup
                    .connect(url)
                    .method(Connection.Method.POST)
                    .userAgent(userAgent)
                    .referrer("https://www.google.co.jp/")
                    .data("txt", params[0])
                    .execute();
            doc = response.parse();
        } catch (Exception e) {
            if (e instanceof HttpStatusException) {
                httpStatusCode = ((HttpStatusException) e).getStatusCode();
            }
            exception = e;
            Log.d(TAG, "doInBackground: " + e.getMessage());
            return null;
        }
        return doc;
    }

    protected void onPostExecute(Document s) {
        String htmlString = s.select("#main-content > div.dsp2.radius_5").html();
        Log.d(TAG, "onPostExecute: \n\n" + htmlString);
        super.onPostExecute(s);
        if (listener != null) {
            if (exception == null) {
                listener.onPostTask(htmlString);
            } else {
                listener.onFailure(exception, httpStatusCode);
            }
        }

    }
}
